package com.gable.runma.model;

import jakarta.persistence.Entity;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;

@Entity
@Data
public class Admin extends User{

}
