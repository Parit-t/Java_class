package com.gable.runma.model;

public enum Gender {
	Male, Female
}
