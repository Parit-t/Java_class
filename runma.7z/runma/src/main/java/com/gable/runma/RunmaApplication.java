package com.gable.runma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunmaApplication.class, args);
	}

}
