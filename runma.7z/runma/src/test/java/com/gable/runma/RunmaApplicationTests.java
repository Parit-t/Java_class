package com.gable.runma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
